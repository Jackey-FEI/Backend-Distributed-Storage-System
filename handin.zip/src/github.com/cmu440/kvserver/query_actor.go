package kvserver

import (
	"encoding/gob"
	"fmt"
	"sync"

	"github.com/cmu440/actor"
)

// Implement your queryActor in this file.
// See example/counter_actor.go for an example actor using the
// github.com/cmu440/actor package.

// TODO (3A, 3B): define your message types as structs
// Message types sent and received by the actor.

type MGet struct {
	Sender *actor.ActorRef
	Key    string
}

type MList struct {
	Sender *actor.ActorRef
	Prefix string
}

type MPut struct {
	Sender *actor.ActorRef
	Key    string
	Value  string
}

type MGetResult struct {
	Value string
	Ok    bool
}

type MListResult struct {
	Entries map[string]string
}

// Reply for Put RPC.
type MPutResult struct {
}

func init() {
	// TODO (3A, 3B): Register message types, e.g.:
	// gob.Register(MyMessage1{})
	gob.Register(MGet{})
	gob.Register(MList{})
	gob.Register(MPut{})
	gob.Register(MGetResult{})
	gob.Register(MListResult{})
	gob.Register(MPutResult{})
}

type queryActor struct {
	// TODO (3A, 3B): implement this!
	context *actor.ActorContext
	data    map[string]string
	lock    sync.Mutex
}

// "Constructor" for queryActors, used in ActorSystem.StartActor.
func newQueryActor(context *actor.ActorContext) actor.Actor {
	return &queryActor{
		context: context,
		data:    make(map[string]string),
		lock:    sync.Mutex{},
		// TODO (3A, 3B): implement this!
	}
}

// OnMessage implements actor.Actor.OnMessage.
func (actor *queryActor) OnMessage(message any) error {
	actor.lock.Lock()
	defer actor.lock.Unlock()
	// TODO (3A, 3B): implement this!
	switch m := message.(type) {
	case MGet:
		_, ok := actor.data[m.Key]
		if !ok {
			result := MGetResult{"", false}
			actor.context.Tell(m.Sender, result)
		} else {
			result := MGetResult{actor.data[m.Key], true}
			actor.context.Tell(m.Sender, result)
		}
	case MList:
		entries := make(map[string]string)
		for k, v := range actor.data {
			if len(k) >= len(m.Prefix) && k[:len(m.Prefix)] == m.Prefix {
				entries[k] = v
			}
		}
		result := MListResult{entries}
		actor.context.Tell(m.Sender, result)
	case MPut:
		actor.data[m.Key] = m.Value
		result := MPutResult{}
		actor.context.Tell(m.Sender, result)
	default:
		// Return an error. The ActorSystem will report this but not
		// do anything else.
		return fmt.Errorf("Unexpected counterActor message type: %T", m)
	}
	return nil

}
